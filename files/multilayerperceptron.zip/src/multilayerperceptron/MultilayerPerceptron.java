/*
 * Universidade Federal de Lavras (UFLA)         |  University of Lavras
 * Departamento de Ciência da Computação (DCC)   |  Department of Computer Science
 * GCC128 - Inteligência Artificial              |  GCC128 - Artificial Intelligence
 * Multilayer Perceptron
 * Prof. Vinicius Ruela Pereira Borges
 * http://viniciusrpb.byethost6.com   . Email: viniciusrpb at icmc.usp.br
 * PS: This code is an adapted version of the one available at:
 * https://physionet.org/challenge/2010/sources/Luiz-Silva/MLP.java 
 */

/*
* The Multilayer Perceptron with a Backpropagation Learning
* INPUT: X[1..n][1..d] : training data
         w_input_hidden[1..j][1..d] : weight coefficients between the input layer
                                      and the hidden layer
         w_hidden_output[1..k][1..j] : weight coefficients between the hidden layer
                                      and the output layer
         labels[1..n][1..b] : labels in binary notation (b, number of bits required to
                                      describe the classes)
         learningRate: the learning rate
*/

package multilayerperceptron;

import input.EasyFile;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;

/**
 *
 * @author Vinicius Ruela Pereira Borges
 */

public class MultilayerPerceptron{

    /** 
     * Creates a new instance of MultilayerPerceptron.
     *
     * @param nroInputs number of neurons in the input layer (generally the number of attributes on input data)
     * @param nroHiddens number of neurons in the hidden layer (provided by user)
     * @param nroOutputs number of neurons in the output layer (depends on the number of bits to describe a class label)
     */
    
    private int nroInputs, nroHidden, nroOutput; 
    
    /** 
     * Creates a new instance of MultilayerPerceptron.
     *
     * @param inputLayer values of each neuron in the input layer
     * @param hiddenLayer values of each neuron in the hidden layer
     * @param outputLayer values of each neuron in the output layer
     */
    
    private double[/* variable */] inputLayer, hiddenLayer, outputLayer;

    private double[/*k*/][/*d*/] w_input_hidden;  // Weight coefficients between the neuron k of the hidden layer
                                                  //  and the input layer i
    private double[/*j*/][/*k*/] w_hidden_output; // Weight coefficients between the neuron j of the output layer
                                                  // and the neuron k of the hidden layer
                       
    private double[/*i*/][/*b*/] binaryLabels;    // Data labels in a binary notation

    private double[/*i*/][/*d*/] X;               // Training data: i examples and d attributes

    private double learningRate = 0.5;           // The learning rate
    
    private int iterations;                      // Number of Iterations

    private int numberOfInstances;               // Number of instances (examples for training)
    
    private int numberOfAttributes;              // Number of attributes of training data
    
    private int numberOfClasses;                 // Number of classes
    
    private double totalError;

    ArrayList<String> classes;       //
    
    public MultilayerPerceptron(int nInput, int nHidden, int nOutput, double[][] data, ArrayList<String> labels,double[][] bLabels, int nc) {

        // Assign the input parameters to all class variables
        nroInputs = nInput;
        nroHidden = nHidden;
        nroOutput = nOutput;

        inputLayer = new double[nInput];
        hiddenLayer = new double[nHidden];
        outputLayer = new double[nOutput];
        
        numberOfInstances = data.length;
        numberOfAttributes = data[0].length;
        numberOfClasses = nc;

        w_input_hidden = new double[nHidden+1][nInput+1];
        w_hidden_output = new double[nOutput+1][nHidden+1];
        
        classes = labels;
        X = data;
        binaryLabels = bLabels;
        
        totalError = 0.0;
    }
   
    /*Get and Set methods*/
    public void setLearningRate(double lr) {
        learningRate = lr;
    }
    
    public double getLearningRate() {
        return learningRate;
    }
    
    public void setIterations(int t) {
        iterations = t;
    }
    
    public int getIterations() {
        return iterations;
    }
    
    /*
    *  Initialize weights with random values between interval [-0.5,0.5[
    */
    
    public void generateRandomWeights() {
        
        // For each 
        for(int k = 0; k < nroHidden; k++)
            for(int d = 0; d < nroInputs; d++) {
                w_input_hidden[k][d] = Math.random();
        }

        for(int j=0; j < nroOutput; j++)
            for(int k=0; k< nroHidden; k++) {
                w_hidden_output[j][k] = Math.random();
        }
        
    }
    
    private void printWeights(){
        
        System.out.println("Weights between Input Layer and the Hidden Layer:");
        
        for(int k=0; k < nroHidden; k++){
            System.out.print("Neuron "+k+": ");
            for(int d=0; d < nroInputs; d++) {
                Formatter fmt = new Formatter();
                // Format 4 decimal places. 
                fmt.format("%.3f",w_input_hidden[k][d]);
                System.out.print(fmt+" ");
            }
            System.out.println();
        }
    
        System.out.println("Weights between Hidden Layer and the Output Layer:");
        
        for(int j=0; j< nroOutput; j++){
            System.out.print("Neuron "+j+": ");
            for(int k=0; k< nroHidden; k++) {
                Formatter fmt = new Formatter();
                fmt.format("%.3f",w_hidden_output[j][k]);
                System.out.print(fmt+" ");
            }
            System.out.println();
        }
        System.out.println("--------------------------------------------------\n");
        
    }
    
    /*Multilayer Perceptron training: for each training pair (x_i,l(x_i)):
      1) Propagation (Forward) step: compute the output y_i 
      2) Backpropagation step: update weights
    
     * Train the network with given a pattern.
     * The pattern is passed through the network and the weights are adjusted
     * by backpropagation, considering the desired output.
     *
     * @param pattern the pattern to be learned
     * @param desiredOutput the desired output for pattern
     * @return the network output before weights adjusting
     */
    public void training(){
        
        System.out.println("Training...");

    }
       
    /*Propagation step: computes the network output
     Activation function: Sigmoid*/
    public void propagation(double[] inputData) {

    }
    
    /*
     Backpropagation step
     */
    public void backpropagation(double[] classLabel) {

        
    }
    
    // Get the number of attributes
    public int getNumberOfAttributes(){
        return numberOfAttributes;
    }
    
    public static void main(String args[]) {
        // TODO code application logic here
        
        Scanner scanner = new Scanner(System.in);
        EasyFile efile = new EasyFile();
        
        double learningRate;
        int numNeuronsHiddenLayer, iterations;
        String filename;
        
        // Enter the input parameters
        boolean keep = false;
        while(keep == false){
            
        
            System.out.print("\nLearning rate - or press ENTER to set a default value (0.1): ");
            try {
                learningRate = Double.parseDouble(scanner.nextLine());
            } catch(Exception e) {
                learningRate = 0.1;
            }

            System.out.print("Number of hidden layer neurons: ");
            try {
                numNeuronsHiddenLayer = Integer.parseInt(scanner.nextLine());
            } catch(Exception e) {
                numNeuronsHiddenLayer = 0;  // Flag to set 2*input + 1 after read signal
            }

            System.out.print("Enter the number of training iterations or press ENTER for default (500): ");
            try {
                iterations = Integer.parseInt(scanner.nextLine());
            } catch(Exception e) {
                iterations = 500;
            }

            System.out.print("Please, select the dataset... ");

            filename = efile.findAndOpenFile();
            try {
                boolean res = efile.openFile(filename);
            } catch(Exception e) {
                System.exit(0);
            }

            // Get the Feature space
            double[][] data = efile.getDataMatrix();

            // Change according to the dataset
            int numNeuronsOutputLayers=1;
            
            // Number of classes
            int nroClasses = 2;

            // Set the binary notation of the label classes
            double[][] bl = new double[4][1];
            bl[0][0] = 0;
            bl[1][0] = 1;
            bl[2][0] = 1;
            bl[3][0] = 0;
            
            // Instance the Multilayer Perceptron
            MultilayerPerceptron mlp = new MultilayerPerceptron(data[0].length,numNeuronsHiddenLayer,numNeuronsOutputLayers,data,efile.getLabels(),bl,nroClasses);

            //Initialize ANN parameters
            mlp.setLearningRate(learningRate);
            mlp.setIterations(iterations);
            //mlp.setVarEpsilon();

            //Initialize the neuron weights
            mlp.generateRandomWeights();

            // Learn the patterns and train the ANN
            mlp.training();

            // Loop until user is satisfied to test the MLP
            System.out.print("\nWould you like to try again? (1-yes, 0-no)");
            try {
                int res = Integer.parseInt(scanner.nextLine());
                if(res == 1){
                    keep = false;
                }else{
                    keep = true;
                }
            } catch(Exception e) {
                keep = false;
            }
            
        }
        System.out.print("\nRun finished!\n");
    }
}

    

