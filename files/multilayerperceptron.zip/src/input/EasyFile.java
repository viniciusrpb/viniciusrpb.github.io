/*
 * Universidade Federal de Lavras (UFLA)         |  University of Lavras
 * Departamento de Ciência da Computação (DCC)   |  Department of Computer Science
 * GCC128 - Inteligência Artificial              |  GCC128 - Artificial Intelligence
 * Multilayer Perceptron: EasyFile class
 * Prof. Vinicius Ruela Pereira Borges
 * http://viniciusrpb.byethost6.com   . Email: viniciusrpb at icmc.usp.br
 
 * DESCRIPTION: A simple class for reading UCI files and storing data as bidimensional arrays.
*/

package input;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 * 
 * @author Vinicius Ruela Pereira Borges
 */
public class EasyFile extends JFrame{
	
    // Variavel que armazena o arquivo
    private File arquivo;

    private BufferedReader br;

    private StringBuffer bufSaida;

    // Store the whole content of dataset in a String
    private String conteudo;

    private ArrayList<String> classes = new ArrayList<String>();

    // Height and Width of the bi-dimensional matrix
    private int width, height;

    public EasyFile() {

    }

    // Open the file
    public boolean openFile(String arq_nome) {

        arquivo = new File(arq_nome);
        String linha;

        // Check if file exists in memory
        if (!arquivo.exists()) {
            return false;
        }

        try {
            br = new BufferedReader(new FileReader(arquivo));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // Count the number of instances in the data set
        bufSaida = new StringBuffer();
        width = 0;
        try {
            while ((linha = br.readLine()) != null) {
                bufSaida.append(linha + "\n");
                width++;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // Close the file
        try {
            br.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // Store the whole content in a String
        conteudo = new String(bufSaida.toString());

        return true;

    }

    // Find file using a JFileChooser and 
    public String findAndOpenFile() {

        JFileChooser jfc_dataset = new JFileChooser();
        String str_input1 = null;
        jfc_dataset.setDialogTitle("Select the data set");
        jfc_dataset.setFileSelectionMode(JFileChooser.FILES_ONLY);
        jfc_dataset.setCurrentDirectory(new File("..."));

        // User choose the file in memory
        if (jfc_dataset.showOpenDialog(this) == javax.swing.JFileChooser.APPROVE_OPTION) {

            //Get selected file and store the path in a String
            File fl = jfc_dataset.getSelectedFile();
            str_input1 = new String(fl.getPath());
        } else {
            System.out.println("Error");
        }
        return str_input1;
    }

    public String getConteudo() {
        return conteudo;
    }

    public ArrayList<String> getLabels() {
        return classes;
    }

    // Read content and buils an array of training data
    public double[][] getDataMatrix() {

        FileReader fr = null;
        String content = conteudo;
        File fl = arquivo;

        try {
            fr = new FileReader(fl);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EasyFile.class.getName()).log(Level.SEVERE, null, ex);
        }

        br = new BufferedReader(fr);

        int at = 0;
        String linha = null;
        double[][] realData;
        double[][] data;

        //First count columns number
        int count = 1;

        char line[] = new char[9000];
        content.getChars(0, content.indexOf("\n"), line, 0);
        for (int i = 0; i < line.length; i++) {
            if (line[i] == ',') {
                count++;
            }
        }

        width = count - 1;
        // Now, count number of lines and gets its values
        data = new double[2000][];
        for (int i = 0; i < 2000; i++) {
            data[i] = new double[width];
            for (int j = 0; j < width; j++) {
                data[i][j] = 0;
            }
        }

        double f;

        count = 0;

        try {
            while ((linha = br.readLine()) != null) {

                StringTokenizer separador = new StringTokenizer(linha, ",");

                at = 0;
                while (separador.hasMoreTokens()) {
                    String word = separador.nextToken();

                    if (at < width) {
                        f = Double.parseDouble(word);
                        data[count][at] = f;
                        at++;
                    } else {
                        classes.add(word);
                    }

                }
                System.out.println("");
                count++;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        height = count - 1;
        realData = new double[height][];
        for (int i = 0; i < height; i++) {
            realData[i] = new double[width];
            for (int j = 0; j < width; j++) {
                realData[i][j] = data[i][j];
            }
        }
        return realData;
    }

}
